/**
 * Created by cmm on 16/5/31.
 */
var mysql = require("mysql");

var mySQL = {
    connection:null
};

var tableName = "shenghuo";
//增删查改的基本语句
var insertSQL = 'INSERT INTO '+ tableName +'(appName,authorName,categoryName,apkName,averageRating,downloadNum,score,commentNum,iconUrl) VALUES(?,?,?,?,?,?,?,?,?)';


mySQL.start = function(dbConfig,callback){
    mySQL.connection = mysql.createConnection(dbConfig);

    mySQL.connection.connect(function(err){
        if(err){
            console.log("数据库连接出错,正在尝试重新连接",err);
            setTimeout(function(){
                mySQL.start(dbConfig,callback);
            }, 2000);
            return ;
        }else{
            console.log("数据库连接成功");
            callback&&callback();
        }
    });

    mySQL.connection.on("error",function(err){
        console.log("数据库连接出错,正在尝试重新连接",err);
        setTimeout(function(){
            mySQL.start(dbConfig,callback);
        }, 1000);
        return ;
    });
};

mySQL.stop = function(callback){
    mySQL.connection.end(function(err){
        if(err){
            console.log("数据库关闭出错",err);
        }else{
            console.log("数据库关闭成功");
            callback&&callback();
        }
    });
};

mySQL.insert = function(obj,callback){
    var arrObj = [obj.appName,obj.authorName,obj.categoryName,obj.apkName,obj.averageRating,obj.downloadNum,obj.score,obj.commentNum,obj.iconUrl];
    mySQL.connection.query(insertSQL,arrObj,function(err,res){
        if(err){
            console.log("[insert error]---",err.message);
        }else{
            console.log("insert success---INSERT-ID",res.insertId);
        }
        callback&&callback();
    });
};

module.exports = mySQL;








