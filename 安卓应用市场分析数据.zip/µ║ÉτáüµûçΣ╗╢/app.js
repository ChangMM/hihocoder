/**
 * Created by cmm on 16/5/31.
 */
var cheerio = require('cheerio');
var superagent = require('superagent');
var mysql = require('./mysql.js');

var dbConfig = 	{
        "host":"localhost",
        "port":3306,
        "user":"root",
        "password":"Hustonline87542701",
        "database":"androidApp"
    };

mysql.start(dbConfig,function(){
    superagent.get('http://sj.qq.com/myapp/cate/appList.htm?orgame=1&categoryId=107&pageSize=150&pageContext=0')
        .end(function (err, res) {
            if (err) {
                console.log(err);
            }
            var data  = JSON.parse(res.text);
            var count = data.count;
            var jsonString   = data.obj;

            (function next(i,length,callback){
                if(i<length){
                    getOneApp(jsonString[i],function(){
                        i++;
                        next(i,length,callback)
                    });
                }else{
                    callback();
                }
            })(0,count,function(){
                mysql.stop();
            });
        });
});

function getOneApp(json,callback){
    var obj = {};
    obj.appName   = json.appName;
    // obj.appId     = json.appId;
    // obj.categoryId = json.categoryId;
    obj.categoryName = json.categoryName;
    obj.downloadNum  = json.appDownCount;
    obj.authorName = json.authorName;
    obj.averageRating = json.averageRating;
    obj.iconUrl = json.iconUrl;
    obj.apkName = json.pkgName;

    superagent.get("http://sj.qq.com/myapp/detail.htm?apkName="+obj.apkName)
        .end(function(err, res){
            // 常规的错误处理
            if (err) {
                console.log(err);
            }
            var $ = cheerio.load(res.text);
            obj.score = $(".com-blue-star-num").html().slice(0,3);
            superagent.get('http://sj.qq.com/myapp/app/comment.htm?apkName='+obj.apkName)
                .end(function (err, res) {
                    if (err) {
                        console.log(err);
                    }
                    var data = JSON.parse(res.text);
                    if(data.obj){
                        obj.commentNum = data.obj.total;
                    }else{
                        obj.commentNum = 0;
                    }
                    mysql.insert(obj,function(){
                        callback&&callback();
                    });
                });
        });
}