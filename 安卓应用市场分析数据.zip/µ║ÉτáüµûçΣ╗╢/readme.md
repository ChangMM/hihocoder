### 代码运行环境
运行机器需要安装，mysql5.6以上，nodejs 0.10以上
首次运行需要进入『源码文件』文件夹，运行 「npm install」命令，同时需要修改mysql.js 及app.js文件中的数据库配置
